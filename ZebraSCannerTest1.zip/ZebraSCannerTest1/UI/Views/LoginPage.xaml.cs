using Microsoft.Maui.Controls;
using ZebraSCannerTest1.UI.Views;

namespace ZebraSCannerTest1.UI.Views;

public partial class LoginPage : ContentPage
{
    public LoginPage()
    {
        InitializeComponent();
    }

    private void OnLoginClicked(object sender, EventArgs e)
    {
        var shell = MauiProgram.ServiceProvider.GetRequiredService<AppShell>();

        Microsoft.Maui.Controls.Application.Current.MainPage = shell;
    }
}